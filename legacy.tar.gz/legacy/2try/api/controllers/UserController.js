/*jshint enforceall: true, esnext: true, node: true*/

/**
 * UserController
 *
 * @description :: Server-side logic for managing users
 * @help        :: See http://sailsjs.org/#!/documentation/concepts/Controllers
 */

module.exports = {
  'getUserList': function (req, res){

  },
  'getUser': function (req, res){

  },
  'addUser': function (req, res){

  },
  'editUser': function (req, res){

  },
  'deleteUser': function (req, res){

  }
};

